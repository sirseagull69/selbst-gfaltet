# Der Bauplan in 9 Schritten

So baust du dir mit Claude Code deine eigene KI, nach dem Vorbild von origami.
Leg `CLAUDE.md` in einen leeren Ordner, starte dort Claude Code (`claude`) und gib die
Aufträge unten nacheinander ein. Erst den nächsten Schritt, wenn der vorige läuft.

Voraussetzung: Ollama ist installiert und ein Modell geladen (`ollama pull gemma4:26b`).
Prüf vorher mit `ki-check.ps1`, was auf deinen PC passt.

---

## 1. Das Grundgerüst
> Lies CLAUDE.md. Bau das Grundgerüst: Node-Server mit einer Chat-Oberfläche im Browser,
> die meine Nachricht an Ollama schickt und die Antwort Wort für Wort anzeigt.
> Unter jeder Antwort Modell und Dauer. Erklär mir danach, wie ich es starte.

**Prüfen:** Server starten, `http://localhost:3000` öffnen, „Hallo“ schreiben.

## 2. Schnell machen
> Sorg dafür, dass der Anfang des Prompts bei jeder Anfrage gleich bleibt (Uhrzeit hinten an
> die Nachricht) und bau das Vorwärmen ein, wie in CLAUDE.md beschrieben.
> Miss die Zeit bis zur ersten Antwort vorher und nachher und zeig mir beide Werte.

**Prüfen:** Server neu starten, Seite öffnen, kurz warten, dann fragen. Die erste Antwort
sollte deutlich schneller kommen als vorher.

## 3. Erste Werkzeuge
> Bau zwei Werkzeuge: `rechnen` (versteht z. B. „100 + 19%“) und `wetter` über Open-Meteo
> (Ort und Tag rein, kurze fertige Antwort raus). Das Modell soll sie selbst aufrufen können.
> Die Werkzeugliste immer komplett mitschicken.

**Prüfen:** „Was sind 249 Euro plus 19 %?“ und „Wie wird das Wetter morgen in Stuttgart?“

## 4. Die Schutzschicht
> Bau die Freigabe-Abfrage und die Regeln aus dem Abschnitt Sicherheit in CLAUDE.md.
> Dann ein Werkzeug `befehl_ausfuehren` für PowerShell: reine Lesebefehle laufen frei,
> alles andere fragt. Schreib Tests mit fiesen Fällen (zusammengesetzte Löschbefehle,
> versteckte Anweisung in einer Datei) und zeig mir, dass sie abgefangen werden.

**Prüfen:** „Wie viel Platz ist auf C?“ läuft ohne Nachfrage. „Lösch die Datei test.txt“ fragt.

## 5. Die Notbremse
> Bau die Notbremse aus CLAUDE.md ein: 3 Fehler, 3-mal dieselbe Aktion oder 20 Schritte,
> dann Abbruch mit Erklärung. Schreib einen Test, der eine Endlosschleife simuliert.

## 6. Ein Gedächtnis
> Bau ein Werkzeug `merken`, das Fakten über mich in `daten/memory.json` speichert, mit
> Rückgängig-Knopf in der Oberfläche. Keine Passwörter oder Gesundheitsdaten speichern.
> Achtung: Neue Einträge ändern den Prompt-Anfang. Sag mir, wie du damit umgehst.

## 7. Login für unterwegs
> Bau einen Login mit Passwort und Zwei-Faktor-Code (Authenticator-App), Sperre nach
> Fehlversuchen. Verwaltungsseiten nur von localhost. Erst wenn das läuft: erklär mir,
> wie ich mit Tailscale Funnel von unterwegs drankomme.

**Prüfen:** Vom Handy aus ohne Code darf nichts gehen.

## 8. Läuft von allein
> Richte ein, dass die KI beim Hochfahren automatisch startet (Windows-Aufgabe, ohne
> Anmeldung), nach einem Absturz neu startet und jede Nacht um 3 Uhr ein Backup von
> `daten/` macht, 14 Tage aufheben.

**Prüfen:** PC neu starten, ohne anzumelden vom Handy aus fragen.

## 9. Optional: Hilfe von Claude
> Bau eine Aufgabenteilung: Kurze Alltagssachen bleiben lokal, Code, Recherche und alles
> über 700 Zeichen geht an Claude über die API (Schlüssel aus `.env`). Entscheiden soll eine
> feste Wortliste, keine KI. Unter jeder Antwort steht, wer geantwortet hat.

---

Mehr zu jedem Schritt, mit echten Messwerten und Pannen: www.selbstgfaltet.de
